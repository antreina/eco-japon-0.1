<?php return array (
  'informaciones.view' => 'App\\Http\\Livewire\\Informaciones\\View',
  'reportes.view' => 'App\\Http\\Livewire\\Reportes\\View',
  'residuos.view' => 'App\\Http\\Livewire\\Residuos\\View',
);